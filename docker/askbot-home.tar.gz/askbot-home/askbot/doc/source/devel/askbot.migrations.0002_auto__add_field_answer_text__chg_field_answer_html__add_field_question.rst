.. _askbot.migrations.0002_auto__add_field_answer_text__chg_field_answer_html__add_field_question:

:mod:`askbot.migrations.0002_auto__add_field_answer_text__chg_field_answer_html__add_field_question`
=============================================================================================

.. automodule:: askbot.migrations.0002_auto__add_field_answer_text__chg_field_answer_html__add_field_question
    :members:
    :undoc-members:
    :show-inheritance:

