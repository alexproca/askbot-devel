.. _askbot.migrations.0003_copy_denorm_text_record_to_posts_for_fulltext_search:

:mod:`askbot.migrations.0003_copy_denorm_text_record_to_posts_for_fulltext_search`
===========================================================================

.. automodule:: askbot.migrations.0003_copy_denorm_text_record_to_posts_for_fulltext_search
    :members:
    :undoc-members:
    :show-inheritance:

