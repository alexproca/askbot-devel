.. _askbot.conf.settings_wrapper:

:mod:`askbot.conf.settings_wrapper`
============================

.. automodule:: askbot.conf.settings_wrapper
    :members:
    :undoc-members:
    :show-inheritance:

