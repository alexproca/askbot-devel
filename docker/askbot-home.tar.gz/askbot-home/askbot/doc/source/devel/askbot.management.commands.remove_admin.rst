.. _askbot.management.commands.remove_admin:

:mod:`askbot.management.commands.remove_admin`
=======================================

.. automodule:: askbot.management.commands.remove_admin
    :members:
    :undoc-members:
    :show-inheritance:

