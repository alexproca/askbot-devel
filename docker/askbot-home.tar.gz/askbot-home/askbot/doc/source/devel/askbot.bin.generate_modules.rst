.. _askbot.bin.generate_modules:

:mod:`askbot.bin.generate_modules`
===========================

.. automodule:: askbot.bin.generate_modules
    :members:
    :undoc-members:
    :show-inheritance:

