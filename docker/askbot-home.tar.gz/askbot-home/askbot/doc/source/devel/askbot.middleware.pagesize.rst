.. _askbot.middleware.pagesize:

:mod:`askbot.middleware.pagesize`
==========================

.. automodule:: askbot.middleware.pagesize
    :members:
    :undoc-members:
    :show-inheritance:

