.. _askbot.bin:

:mod:`askbot.bin`
==========

.. automodule:: askbot.bin
    :members:
    :undoc-members:
    :show-inheritance:

.. _modules::

:mod:`Modules`
-------


* :ref:`askbot.bin.generate_modules`
* :ref:`askbot.bin.show_profile_stats`

