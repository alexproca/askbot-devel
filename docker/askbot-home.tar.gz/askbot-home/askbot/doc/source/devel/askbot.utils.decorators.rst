.. _askbot.utils.decorators:

:mod:`askbot.utils.decorators`
=======================

.. automodule:: askbot.utils.decorators
    :members:
    :undoc-members:
    :show-inheritance:

