.. _askbot.conf.vote_rules:

:mod:`askbot.conf.vote_rules`
======================

.. automodule:: askbot.conf.vote_rules
    :members:
    :undoc-members:
    :show-inheritance:

