.. _askbot.models.base:

:mod:`askbot.models.base`
==================

.. automodule:: askbot.models.base
    :members:
    :undoc-members:
    :show-inheritance:

