.. _askbot.conf.reputation_changes:

:mod:`askbot.conf.reputation_changes`
==============================

.. automodule:: askbot.conf.reputation_changes
    :members:
    :undoc-members:
    :show-inheritance:

