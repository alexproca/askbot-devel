.. _askbot.management.commands.base_command:

:mod:`askbot.management.commands.base_command`
=======================================

.. automodule:: askbot.management.commands.base_command
    :members:
    :undoc-members:
    :show-inheritance:

