.. _askbot.migrations.0010_add_receiving_user_to_activity_model:

:mod:`askbot.migrations.0010_add_receiving_user_to_activity_model`
===========================================================

.. automodule:: askbot.migrations.0010_add_receiving_user_to_activity_model
    :members:
    :undoc-members:
    :show-inheritance:

