.. _askbot.utils.colors:

:mod:`askbot.utils.colors`
===================

.. automodule:: askbot.utils.colors
    :members:
    :undoc-members:
    :show-inheritance:

